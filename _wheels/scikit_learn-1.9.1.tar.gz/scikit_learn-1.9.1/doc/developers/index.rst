:orphan:

.. _developers_guide:

=================
Developer's Guide
=================

.. toctree::

   contributing
   development_setup
   global_configuration
   minimal_reproducer
   develop
   tips
   utilities
   performance
   cython
   misc_info
   bug_triaging
   maintainer
   plotting
   callbacks
