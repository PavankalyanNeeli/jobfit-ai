.. _user_guide:

==========
User Guide
==========

.. toctree::
   :numbered:
   :maxdepth: 3

   supervised_learning.rst
   unsupervised_learning.rst
   model_selection.rst
   metadata_routing.rst
   inspection.rst
   visualizations.rst
   callbacks.rst
   data_transforms.rst
   datasets.rst
   computing.rst
   model_persistence.rst
   common_pitfalls.rst
   data_interoperability.rst
   machine_learning_map.rst
   presentations.rst
